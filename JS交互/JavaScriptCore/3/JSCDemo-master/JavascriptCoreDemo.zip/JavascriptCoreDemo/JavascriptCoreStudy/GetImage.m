//
//  GetImage.m
//  JavascriptCoreStudy
//
//  Created by shange on 2017/4/13.
//  Copyright © 2017年 jinshan. All rights reserved.
//

#import "GetImage.h"


@implementation GetImage


@end
