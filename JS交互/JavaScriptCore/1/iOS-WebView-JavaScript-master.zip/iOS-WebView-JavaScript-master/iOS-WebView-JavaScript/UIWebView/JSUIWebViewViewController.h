//
//  JSUIWebViewViewController.h
//  WebViewJS
//
//  Created by Jakey on 16/4/10.
//  Copyright © 2016年 www.skyfox.org All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSUIWebViewViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *myWebView;

@end
